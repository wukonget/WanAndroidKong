package com.pengc.wanandroidkong.activity

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import cn.droidlover.xdroidmvp.mvp.XActivity
import com.pengc.wanandroidkong.R
import com.pengc.wanandroidkong.presenter.MainPresenter

class MainActivity : XActivity<MainPresenter>(){
    override fun initData(savedInstanceState: Bundle?) {
        p
    }

    override fun getLayoutId(): Int {
        return R.layout.activity_main
    }

    override fun newP(): MainPresenter {
        return MainPresenter()
    }
}