package com.pengc.wanandroidkong.utils

import android.content.Intent
import android.support.v7.app.AppCompatActivity

class WebUtil {

    companion object{
        fun loadUrl(activity: AppCompatActivity, url :String){
            val intent = Intent(activity,WebViewActivity::class.java)
            intent.putExtra(WebViewActivity.WEBVIEWURLKEY,url)
            activity.startActivity(intent)
        }
    }

}