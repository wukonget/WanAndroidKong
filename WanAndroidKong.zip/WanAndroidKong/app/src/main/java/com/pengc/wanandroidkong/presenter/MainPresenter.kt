package com.pengc.wanandroidkong.presenter

import cn.droidlover.xdroidmvp.mvp.XPresent
import com.pengc.wanandroidkong.activity.MainActivity

class MainPresenter : XPresent<MainActivity>() {
}