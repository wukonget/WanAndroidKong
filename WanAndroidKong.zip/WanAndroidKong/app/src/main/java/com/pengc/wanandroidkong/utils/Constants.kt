package com.pengc.wanandroidkong.utils

class Constants {

    companion object{
        val SEARCH_KEY_TAG = "search_key_tag"
    }
}