package com.pengc.wanandroidkong.http

class Api {

    companion object {
        val BASE_URL = "https://www.wanandroid.com"
        val RequestSuccess = "0"//请求成功
        val NOTLOGIN = "-1001"//未登录
        val OTHER_ERROR = "-1"//其他错误
    }


}