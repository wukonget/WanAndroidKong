package com.pengc.wanandroidkong.bean

data class HotSearchKey(
    var id : Int,
    var link:String,
    var name:String,
    var order:Int,
    var visible:Int
) {
}