package cn.droidlover.xdroidmvp.router;

import android.app.Activity;

/**
 * Created by wanglei on 2016/11/29.
 */

public class SimpleRouterCallback implements RouterCallback {

    @Override
    public void onBefore(Activity from, Class<?> to) {

    }

    @Override
    public void onNext(Activity from, Class<?> to) {

    }

    @Override
    public void onError(Activity from, Class<?> to, Throwable throwable) {

    }
}
