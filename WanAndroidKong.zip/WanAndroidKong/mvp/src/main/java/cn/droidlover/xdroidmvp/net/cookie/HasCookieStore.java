package cn.droidlover.xdroidmvp.net.cookie;

/**
 * Created by wanglei on 2017/9/3.
 */

public interface HasCookieStore {
    CookieStore getCookieStore();
}
